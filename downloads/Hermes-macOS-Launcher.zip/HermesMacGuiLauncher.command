#!/bin/bash

set -euo pipefail

APP_TITLE="Hermes Agent macOS 桌面控制台"
OFFICIAL_INSTALL_URL="https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh"
OFFICIAL_REPO_URL="https://github.com/NousResearch/hermes-agent"
OFFICIAL_DOCS_URL="https://hermes-agent.nousresearch.com/docs/getting-started/installation/"

DEFAULT_HERMES_HOME="$HOME/.hermes"
DEFAULT_INSTALL_DIR="$DEFAULT_HERMES_HOME/hermes-agent"

HERMES_HOME="${HERMES_HOME:-$DEFAULT_HERMES_HOME}"
INSTALL_DIR="${HERMES_INSTALL_DIR:-$DEFAULT_INSTALL_DIR}"
BRANCH="main"

LAUNCHER_LOG_DIR="$HERMES_HOME/logs/launcher"
LAUNCHER_STATE_PATH="$HERMES_HOME/launcher-state.env"

LAST_ACTION_SUMMARY="启动器已就绪"
LOCAL_CHAT_VERIFIED="false"
OPENCLAW_PREVIEWED="false"
OPENCLAW_IMPORTED="false"

HERMES_COMMAND=""
HERMES_INSTALLED="false"
MODEL_READY="false"
HAS_MODEL_CONFIG="false"
HAS_API_KEY="false"
GATEWAY_CONFIGURED="false"
GATEWAY_RUNTIME="false"
GATEWAY_NEEDS_DEPS="false"
GATEWAY_ACCESS_POLICY="false"
CONNECTED_PLATFORMS=""
OPENCLAW_LIST=""

RECOMMENDATION_HEADLINE=""
RECOMMENDATION_BODY=""
RECOMMENDATION_HINT=""
RECOMMENDATION_ACTION_ID=""
RECOMMENDATION_LABEL=""

show_message() {
    local message="$1"
    /usr/bin/osascript - "$message" "$APP_TITLE" <<'OSA'
on run argv
    display dialog (item 1 of argv) with title (item 2 of argv) buttons {"确定"} default button "确定"
end run
OSA
}

show_warning() {
    local message="$1"
    /usr/bin/osascript - "$message" "$APP_TITLE" <<'OSA'
on run argv
    display dialog (item 1 of argv) with title (item 2 of argv) buttons {"确定"} default button "确定" with icon caution
end run
OSA
}

prompt_text() {
    local prompt="$1"
    local default_value="$2"
    /usr/bin/osascript - "$prompt" "$default_value" "$APP_TITLE" <<'OSA'
on run argv
    set resultRecord to display dialog (item 1 of argv) default answer (item 2 of argv) with title (item 3 of argv) buttons {"取消", "确定"} default button "确定" cancel button "取消"
    return text returned of resultRecord
end run
OSA
}

prompt_yes_no() {
    local prompt="$1"
    local default_button="${2:-是}"
    /usr/bin/osascript - "$prompt" "$default_button" "$APP_TITLE" <<'OSA'
on run argv
    set resultRecord to display dialog (item 1 of argv) with title (item 3 of argv) buttons {"否", "是"} default button (item 2 of argv) cancel button "否"
    return button returned of resultRecord
end run
OSA
}

prompt_uninstall_mode() {
    local prompt="$1"
    /usr/bin/osascript - "$prompt" "$APP_TITLE" <<'OSA'
on run argv
    set resultRecord to display dialog (item 1 of argv) with title (item 2 of argv) buttons {"取消", "标准卸载", "彻底卸载"} default button "标准卸载" cancel button "取消" with icon caution
    return button returned of resultRecord
end run
OSA
}

choose_from_list() {
    local prompt="$1"
    local default_item="$2"
    shift 2
    local items_text
    items_text="$(printf '%s\n' "$@")"
    /usr/bin/osascript - "$prompt" "$APP_TITLE" "$default_item" "$items_text" <<'OSA'
on run argv
    set AppleScript's text item delimiters to linefeed
    set options to paragraphs of (item 4 of argv)
    set picked to choose from list options with title (item 2 of argv) with prompt (item 1 of argv) default items {(item 3 of argv)} OK button name "确定" cancel button name "退出" without multiple selections allowed and empty selection allowed
    if picked is false then
        return "__CANCEL__"
    end if
    return item 1 of picked
end run
OSA
}

timestamp_now() {
    date '+%Y-%m-%d %H:%M:%S'
}

set_last_action() {
    LAST_ACTION_SUMMARY="[$(timestamp_now)] $1"
}

ensure_launcher_dirs() {
    mkdir -p "$HERMES_HOME" "$LAUNCHER_LOG_DIR"
}

build_log_path() {
    local slug="$1"
    ensure_launcher_dirs
    printf '%s/%s-%s.log\n' "$LAUNCHER_LOG_DIR" "$(date '+%Y%m%d-%H%M%S')" "$slug"
}

load_launcher_state() {
    LOCAL_CHAT_VERIFIED="false"
    OPENCLAW_PREVIEWED="false"
    OPENCLAW_IMPORTED="false"

    if [[ -f "$LAUNCHER_STATE_PATH" ]]; then
        # shellcheck disable=SC1090
        source "$LAUNCHER_STATE_PATH" || true
    fi
}

save_launcher_state() {
    ensure_launcher_dirs
    cat >"$LAUNCHER_STATE_PATH" <<EOF
LOCAL_CHAT_VERIFIED="${LOCAL_CHAT_VERIFIED}"
OPENCLAW_PREVIEWED="${OPENCLAW_PREVIEWED}"
OPENCLAW_IMPORTED="${OPENCLAW_IMPORTED}"
EOF
}

resolve_hermes_command() {
    local candidates=(
        "$INSTALL_DIR/venv/bin/hermes"
        "$HOME/.local/bin/hermes"
    )
    local candidate=""
    for candidate in "${candidates[@]}"; do
        if [[ -x "$candidate" ]]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    if command -v hermes >/dev/null 2>&1; then
        command -v hermes
        return 0
    fi

    return 1
}

ensure_config_scaffold() {
    local install_dir="$1"
    local hermes_home="$2"
    mkdir -p \
        "$hermes_home/cron" \
        "$hermes_home/sessions" \
        "$hermes_home/logs" \
        "$hermes_home/pairing" \
        "$hermes_home/hooks" \
        "$hermes_home/image_cache" \
        "$hermes_home/audio_cache" \
        "$hermes_home/memories" \
        "$hermes_home/skills" \
        "$hermes_home/whatsapp/session"

    if [[ ! -f "$hermes_home/.env" ]]; then
        if [[ -f "$install_dir/.env.example" ]]; then
            cp "$install_dir/.env.example" "$hermes_home/.env"
        else
            : >"$hermes_home/.env"
        fi
    fi

    if [[ ! -f "$hermes_home/config.yaml" ]]; then
        if [[ -f "$install_dir/cli-config.yaml.example" ]]; then
            cp "$install_dir/cli-config.yaml.example" "$hermes_home/config.yaml"
        else
            : >"$hermes_home/config.yaml"
        fi
    fi

    if [[ ! -f "$hermes_home/SOUL.md" ]]; then
        cat >"$hermes_home/SOUL.md" <<'EOF'
# Hermes Agent Persona

默认使用简体中文回答，除非我明确要求英文。
EOF
    fi
}

test_hermes_installed() {
    [[ -x "$INSTALL_DIR/venv/bin/hermes" || -x "$INSTALL_DIR/hermes" ]]
}

test_model_configured() {
    local config_path="$HERMES_HOME/config.yaml"
    local env_path="$HERMES_HOME/.env"
    local auth_path="$HERMES_HOME/auth.json"

    HAS_MODEL_CONFIG="false"
    HAS_API_KEY="false"

    if [[ -f "$config_path" ]]; then
        if grep -Eq '^[[:space:]]*model[[:space:]]*:' "$config_path" && grep -Eq '^[[:space:]]+default[[:space:]]*:[[:space:]]*\S+' "$config_path"; then
            HAS_MODEL_CONFIG="true"
        elif grep -Eq '^[[:space:]]+model[[:space:]]*:[[:space:]]*\S+' "$config_path"; then
            HAS_MODEL_CONFIG="true"
        fi
    fi

    if [[ -f "$env_path" ]] && grep -Eq '^[[:space:]]*[A-Z0-9_]*API_KEY[[:space:]]*=[[:space:]]*[^#[:space:]]+' "$env_path"; then
        HAS_API_KEY="true"
    fi

    if [[ "$HAS_API_KEY" != "true" && -f "$auth_path" ]] && command -v python3 >/dev/null 2>&1; then
        if python3 - "$auth_path" <<'PY'
import json, sys
path = sys.argv[1]
try:
    data = json.load(open(path, 'r', encoding='utf-8'))
    provider = data.get('active_provider')
    entry = (data.get('providers') or {}).get(provider or '', {})
    ok = any(entry.get(k) for k in ('access_token', 'agent_key', 'api_key', 'refresh_token'))
    sys.exit(0 if ok else 1)
except Exception:
    sys.exit(1)
PY
        then
            HAS_API_KEY="true"
        fi
    fi

    if [[ "$HAS_MODEL_CONFIG" == "true" && "$HAS_API_KEY" == "true" ]]; then
        MODEL_READY="true"
    else
        MODEL_READY="false"
    fi
}

detect_openclaw_sources() {
    local candidates=(
        "$HOME/.openclaw"
        "$HOME/.clawdbot"
        "$HOME/.moldbot"
    )
    local found=()
    local item=""
    for item in "${candidates[@]}"; do
        if [[ -e "$item" ]]; then
            found+=("$item")
        fi
    done
    OPENCLAW_LIST="$(printf '%s\n' "${found[@]:-}" | sed '/^$/d' | paste -sd '; ' -)"
}

detect_gateway_status() {
    local env_path="$HERMES_HOME/.env"
    CONNECTED_PLATFORMS=""
    GATEWAY_CONFIGURED="false"
    GATEWAY_RUNTIME="false"
    GATEWAY_NEEDS_DEPS="false"
    GATEWAY_ACCESS_POLICY="false"

    if pgrep -af 'hermes.*gateway|venv/bin/python.*gateway|python.*gateway.run' >/dev/null 2>&1; then
        GATEWAY_RUNTIME="true"
    fi

    if [[ -f "$env_path" ]]; then
        local names=()
        grep -Eq '^[[:space:]]*TELEGRAM_BOT_TOKEN[[:space:]]*=' "$env_path" && names+=("telegram")
        grep -Eq '^[[:space:]]*DISCORD_BOT_TOKEN[[:space:]]*=' "$env_path" && names+=("discord")
        grep -Eq '^[[:space:]]*SLACK_BOT_TOKEN[[:space:]]*=' "$env_path" && names+=("slack")
        grep -Eq '^[[:space:]]*WEIXIN_ACCOUNT_ID[[:space:]]*=' "$env_path" && names+=("weixin")
        grep -Eq '^[[:space:]]*WHATSAPP_ENABLED[[:space:]]*=' "$env_path" && names+=("whatsapp")
        grep -Eq '^[[:space:]]*MATRIX_HOMESERVER_URL[[:space:]]*=' "$env_path" && names+=("matrix")
        grep -Eq '^[[:space:]]*DINGTALK_CLIENT_ID[[:space:]]*=' "$env_path" && names+=("dingtalk")
        grep -Eq '^[[:space:]]*FEISHU_APP_ID[[:space:]]*=' "$env_path" && names+=("feishu")
        grep -Eq '^[[:space:]]*WECOM_BOT_ID[[:space:]]*=' "$env_path" && names+=("wecom")
        grep -Eq '^[[:space:]]*BLUEBUBBLES_SERVER_URL[[:space:]]*=' "$env_path" && names+=("bluebubbles")
        grep -Eq '^[[:space:]]*(TELEGRAM|DISCORD|SLACK|WHATSAPP|MATRIX|DINGTALK|FEISHU|WEIXIN|BLUEBUBBLES)_ALLOWED_USERS[[:space:]]*=' "$env_path" && GATEWAY_ACCESS_POLICY="true"
        grep -Eq '^[[:space:]]*GATEWAY_ALLOW_ALL_USERS[[:space:]]*=[[:space:]]*true[[:space:]]*$' "$env_path" && GATEWAY_ACCESS_POLICY="true"
        grep -Eq '^[[:space:]]*WEIXIN_ALLOW_ALL_USERS[[:space:]]*=[[:space:]]*true[[:space:]]*$' "$env_path" && GATEWAY_ACCESS_POLICY="true"
        grep -Eq '^[[:space:]]*WEIXIN_DM_POLICY[[:space:]]*=[[:space:]]*(pairing|open|allowlist)[[:space:]]*$' "$env_path" && GATEWAY_ACCESS_POLICY="true"

        CONNECTED_PLATFORMS="$(printf '%s\n' "${names[@]:-}" | sed '/^$/d' | paste -sd '、' -)"
        if [[ -n "$CONNECTED_PLATFORMS" ]]; then
            GATEWAY_CONFIGURED="true"
        fi
    fi

    local py=""
    if [[ -x "$INSTALL_DIR/venv/bin/python" ]]; then
        py="$INSTALL_DIR/venv/bin/python"
    elif command -v python3 >/dev/null 2>&1; then
        py="$(command -v python3)"
    fi

    if [[ "$GATEWAY_CONFIGURED" == "true" && -n "$py" ]]; then
        if [[ "$CONNECTED_PLATFORMS" == *"telegram"* ]]; then
            if ! "$py" -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('telegram') else 1)" >/dev/null 2>&1; then
                GATEWAY_NEEDS_DEPS="true"
            fi
        fi
        if [[ "$CONNECTED_PLATFORMS" == *"discord"* ]]; then
            if ! "$py" -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('discord') else 1)" >/dev/null 2>&1; then
                GATEWAY_NEEDS_DEPS="true"
            fi
        fi
        if [[ "$CONNECTED_PLATFORMS" == *"slack"* ]]; then
            if ! "$py" -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('slack_sdk') else 1)" >/dev/null 2>&1; then
                GATEWAY_NEEDS_DEPS="true"
            fi
        fi
    fi
}

collect_state() {
    load_launcher_state
    ensure_launcher_dirs

    if HERMES_COMMAND="$(resolve_hermes_command 2>/dev/null)"; then
        :
    else
        HERMES_COMMAND=""
    fi

    if test_hermes_installed || [[ -n "$HERMES_COMMAND" ]]; then
        HERMES_INSTALLED="true"
        ensure_config_scaffold "$INSTALL_DIR" "$HERMES_HOME"
    else
        HERMES_INSTALLED="false"
    fi

    test_model_configured
    detect_openclaw_sources
    detect_gateway_status
    compute_recommendation
}

compute_recommendation() {
    if [[ "$HERMES_INSTALLED" != "true" ]]; then
        RECOMMENDATION_HEADLINE="尚未安装 Hermes"
        RECOMMENDATION_BODY="当前没有检测到可用的 Hermes 命令。先完成安装，再继续后续配置。"
        RECOMMENDATION_HINT="官方 macOS 路线是 install.sh。启动器会默认跳过官方 setup，回到自己的分步引导。"
        RECOMMENDATION_ACTION_ID="install"
        RECOMMENDATION_LABEL="安装 / 更新 Hermes"
        return
    fi

    if [[ -n "$OPENCLAW_LIST" && "$OPENCLAW_IMPORTED" != "true" ]]; then
        if [[ "$OPENCLAW_PREVIEWED" == "true" ]]; then
            RECOMMENDATION_HEADLINE="可正式导入 OpenClaw"
            RECOMMENDATION_BODY="已检测到 OpenClaw 来源目录，并记录到你已经做过预览导入。"
            RECOMMENDATION_HINT="确认预览结果没问题后，再执行正式导入。"
            RECOMMENDATION_ACTION_ID="openclaw-import"
            RECOMMENDATION_LABEL="正式导入 OpenClaw"
        else
            RECOMMENDATION_HEADLINE="可预览导入 OpenClaw"
            RECOMMENDATION_BODY="已检测到 OpenClaw 来源目录，建议先预览，再决定是否正式导入。"
            RECOMMENDATION_HINT="预览不会改写 Hermes 配置。"
            RECOMMENDATION_ACTION_ID="openclaw-preview"
            RECOMMENDATION_LABEL="预览导入 OpenClaw"
        fi
        return
    fi

    if [[ "$MODEL_READY" != "true" ]]; then
        RECOMMENDATION_HEADLINE="需要配置模型与 API Key"
        RECOMMENDATION_BODY="还没有检测到一套完整可用的模型配置。"
        RECOMMENDATION_HINT="官方文档建议安装后先完成 provider 和 API Key 配置，再开始对话。"
        RECOMMENDATION_ACTION_ID="model"
        RECOMMENDATION_LABEL="配置模型与 API Key"
        return
    fi

    if [[ "$LOCAL_CHAT_VERIFIED" != "true" ]]; then
        RECOMMENDATION_HEADLINE="先验证本地对话"
        RECOMMENDATION_BODY="模型配置看起来已经就绪，建议先在本机终端里确认 Hermes 能正常回复。"
        RECOMMENDATION_HINT="验证通过后，再决定是否配置消息渠道。"
        RECOMMENDATION_ACTION_ID="launch"
        RECOMMENDATION_LABEL="启动本地对话"
        return
    fi

    if [[ "$GATEWAY_RUNTIME" == "true" || "$GATEWAY_CONFIGURED" == "true" ]]; then
        RECOMMENDATION_HEADLINE="开始对话"
        RECOMMENDATION_BODY="本地对话已经可用。$( [[ "$GATEWAY_CONFIGURED" == "true" ]] && printf '同时已检测到消息渠道配置。' || printf '如需脱离电脑持续对话，可继续配置消息渠道。' )"
        if [[ "$GATEWAY_RUNTIME" == "true" ]]; then
            RECOMMENDATION_HINT="消息网关正在运行。你可以直接继续本地对话，或保持网关终端在线。"
        elif [[ "$GATEWAY_CONFIGURED" == "true" ]]; then
            RECOMMENDATION_HINT="你可以继续本地对话，也可以直接启动消息网关。"
        else
            RECOMMENDATION_HINT="当前还没有检测到消息渠道配置。"
        fi
        RECOMMENDATION_ACTION_ID="use-mode"
        RECOMMENDATION_LABEL="开始对话"
        return
    fi

    RECOMMENDATION_HEADLINE="可继续配置消息渠道"
    RECOMMENDATION_BODY="本地对话已经验证通过，但还没有检测到有效的消息渠道配置。"
    RECOMMENDATION_HINT="完成渠道配置后，下一步就是启动消息网关。"
    RECOMMENDATION_ACTION_ID="gateway-setup"
    RECOMMENDATION_LABEL="配置消息渠道"
}

status_text() {
    cat <<EOF
当前状态：$RECOMMENDATION_HEADLINE

$RECOMMENDATION_BODY

当前操作：$RECOMMENDATION_LABEL
$RECOMMENDATION_HINT

数据目录：$HERMES_HOME
安装目录：$INSTALL_DIR
Git 分支：$BRANCH
Hermes 命令：${HERMES_COMMAND:-未找到}
最近操作：$LAST_ACTION_SUMMARY
EOF
}

quick_check_summary() {
    cat <<EOF
安装状态：$( [[ "$HERMES_INSTALLED" == "true" ]] && printf '已安装' || printf '未安装' )
模型配置：$( [[ "$HAS_MODEL_CONFIG" == "true" ]] && printf '已检测到' || printf '未检测到' )
API Key：$( [[ "$HAS_API_KEY" == "true" ]] && printf '已检测到' || printf '未检测到' )
本地对话验证：$( [[ "$LOCAL_CHAT_VERIFIED" == "true" ]] && printf '已记录完成' || printf '尚未记录' )
OpenClaw 来源：$( [[ -n "$OPENCLAW_LIST" ]] && printf '%s' "$OPENCLAW_LIST" || printf '未检测到' )
消息渠道配置：$( [[ "$GATEWAY_CONFIGURED" == "true" ]] && printf '%s' "$CONNECTED_PLATFORMS" || printf '未检测到' )
消息网关运行：$( [[ "$GATEWAY_RUNTIME" == "true" ]] && printf '运行中' || printf '未运行' )
消息渠道依赖：$( [[ "$GATEWAY_NEEDS_DEPS" == "true" ]] && printf '缺失，启动网关前需先安装' || printf '未发现缺失' )
EOF
}

write_temp_command_script() {
    local payload="$1"
    local title="$2"
    local log_path="${3:-}"
    local script_path
    script_path="/tmp/hermes-launcher-$(date '+%Y%m%d-%H%M%S')-$RANDOM.sh"
    cat >"$script_path" <<EOF
#!/bin/bash
export HERMES_HOME=$(printf '%q' "$HERMES_HOME")
export HERMES_INSTALL_DIR=$(printf '%q' "$INSTALL_DIR")
export PATH=$(printf '%q' "$HOME/.local/bin:$PATH")
export PYTHONIOENCODING=utf-8
export PYTHONUTF8=1
printf '\033]0;%s\007' $(printf '%q' "$title")
$( [[ -n "$log_path" ]] && printf 'exec > >(tee -a %s) 2>&1\n' "$(printf '%q' "$log_path")" )
$payload
EOF
    chmod +x "$script_path"
    printf '%s\n' "$script_path"
}

run_in_terminal() {
    local payload="$1"
    local title="$2"
    local log_path="${3:-}"
    local script_path
    script_path="$(write_temp_command_script "$payload" "$title" "$log_path")"
    /usr/bin/osascript - "$script_path" <<'OSA'
on run argv
    tell application "Terminal"
        activate
        do script ("bash " & quoted form of (item 1 of argv))
    end tell
end run
OSA
}

open_path() {
    local path="$1"
    if [[ -e "$path" ]]; then
        open "$path"
    else
        show_warning "路径不存在：$path"
    fi
}

require_hermes() {
    if [[ -z "$HERMES_COMMAND" ]]; then
        show_warning "当前没有检测到可用的 Hermes 命令。请先安装 Hermes。"
        return 1
    fi
    return 0
}

launch_install() {
    local chosen_install_dir=""
    local chosen_branch=""
    local use_no_venv="false"
    local skip_setup="true"

    chosen_install_dir="$(prompt_text "安装目录" "$INSTALL_DIR")" || return 0
    [[ -z "$chosen_install_dir" ]] && chosen_install_dir="$DEFAULT_INSTALL_DIR"

    chosen_branch="$(prompt_text "Git 分支" "$BRANCH")" || return 0
    [[ -z "$chosen_branch" ]] && chosen_branch="main"

    if [[ "$(prompt_yes_no "是否跳过虚拟环境？通常选“否”。" "否")" == "是" ]]; then
        use_no_venv="true"
    fi
    if [[ "$(prompt_yes_no "安装完成后是否跳过官方 setup，直接回到启动器继续引导？通常选“是”。" "是")" == "否" ]]; then
        skip_setup="false"
    fi

    INSTALL_DIR="$chosen_install_dir"
    BRANCH="$chosen_branch"

    local log_path
    log_path="$(build_log_path "install")"

    local payload=""
    payload+="cd $(printf '%q' "$HOME")"$'\n'
    payload+="curl -fsSL $(printf '%q' "$OFFICIAL_INSTALL_URL") | bash -s -- --branch $(printf '%q' "$BRANCH") --dir $(printf '%q' "$INSTALL_DIR")"
    [[ "$use_no_venv" == "true" ]] && payload+=" --no-venv"
    [[ "$skip_setup" == "true" ]] && payload+=" --skip-setup"
    payload+=$'\n'
    payload+='echo'
    payload+='echo "安装流程已结束，可关闭此终端窗口。"'$'\n'

    set_last_action "已启动安装或更新，日志：$log_path"
    run_in_terminal "$payload" "Hermes 安装或更新" "$log_path"
    show_message "已打开安装终端。安装结束后回到启动器，状态会根据当前文件重新计算。"
}

run_hermes_terminal_action() {
    local label="$1"
    local hermes_args="$2"
    local keep_note="${3:-命令执行结束后，可关闭窗口。}"
    require_hermes || return 0

    local log_path
    log_path="$(build_log_path "$label")"
    local payload=""
    payload+="cd $(printf '%q' "$INSTALL_DIR")"$'\n'
    payload+="$(printf '%q' "$HERMES_COMMAND") $hermes_args"$'\n'
    if [[ -n "$keep_note" ]]; then
        payload+='echo'
        payload+="echo $(printf '%q' "$keep_note")"$'\n'
    fi

    set_last_action "已启动 $label，日志：$log_path"
    run_in_terminal "$payload" "Hermes $label" "$log_path"
}

launch_local_chat() {
    run_hermes_terminal_action "本地对话" "" ""
    show_message "本地对话终端已经打开。请先实际提问一轮，确认 Hermes 能正常回复。验证完成后，再回到启动器继续下一步。"
}

mark_local_chat_verified() {
    LOCAL_CHAT_VERIFIED="true"
    save_launcher_state
    set_last_action "已记录本地对话验证通过"
}

preview_openclaw() {
    require_hermes || return 0
    OPENCLAW_PREVIEWED="true"
    save_launcher_state
    run_hermes_terminal_action "OpenClaw 预览导入" "claw migrate --dry-run"
}

import_openclaw() {
    require_hermes || return 0
    if [[ "$(prompt_yes_no "正式导入会迁移模型、API Key、记忆和部分渠道配置。是否继续？" "否")" != "是" ]]; then
        return 0
    fi
    OPENCLAW_PREVIEWED="true"
    OPENCLAW_IMPORTED="true"
    save_launcher_state
    run_hermes_terminal_action "OpenClaw 正式导入" "claw migrate --preset full"
}

configure_model() {
    run_hermes_terminal_action "模型配置" "model"
    show_message "模型配置终端已打开。关闭终端后，重新回到启动器即可看到最新检测结果。"
}

configure_gateway() {
    run_hermes_terminal_action "消息渠道配置" "gateway setup"
    show_message "消息渠道配置终端已打开。保存并退出后，再回到启动器继续。"
}

install_messaging_and_gateway() {
    require_hermes || return 0
    local log_path
    log_path="$(build_log_path "gateway")"
    local payload=""
    payload+="cd $(printf '%q' "$INSTALL_DIR")"$'\n'
    if [[ "$GATEWAY_NEEDS_DEPS" == "true" ]]; then
        if [[ -x "$INSTALL_DIR/venv/bin/uv" ]]; then
            payload+="$(printf '%q' "$INSTALL_DIR/venv/bin/uv") pip install -e \".[messaging]\""$'\n'
        else
            payload+="uv pip install -e \".[messaging]\""$'\n'
        fi
    fi
    payload+="$(printf '%q' "$HERMES_COMMAND") gateway"$'\n'
    set_last_action "已启动消息网关，日志：$log_path"
    run_in_terminal "$payload" "Hermes 消息网关" "$log_path"
    show_message "消息网关终端已打开。要保持渠道在线，请不要关闭这个终端窗口。"
}

run_doctor() {
    run_hermes_terminal_action "doctor" "doctor"
}

run_update() {
    run_hermes_terminal_action "update" "update"
}

run_tools() {
    run_hermes_terminal_action "tools" "tools"
}

run_full_setup() {
    run_hermes_terminal_action "完整 setup" "setup"
}

uninstall_hermes() {
    if [[ "$HERMES_INSTALLED" != "true" && ! -d "$HERMES_HOME" ]]; then
        show_warning "当前没有检测到可卸载的 Hermes 安装或数据目录。"
        return 0
    fi

    local mode=""
    mode="$(prompt_uninstall_mode "选择卸载方式：\n\n标准卸载：删除程序，保留 ~/.hermes 数据。\n彻底卸载：同时删除 ~/.hermes 数据。")" || return 0

    local log_path
    log_path="$(build_log_path "uninstall")"
    local payload=""
    payload+="rm -f $(printf '%q' "$HOME/.local/bin/hermes")"$'\n'
    payload+="rm -rf $(printf '%q' "$INSTALL_DIR")"$'\n'
    if [[ "$mode" == "彻底卸载" ]]; then
        payload+="rm -rf $(printf '%q' "$HERMES_HOME")"$'\n'
    fi
    payload+='echo'
    payload+='echo "卸载流程已结束，可关闭此终端窗口。"'$'\n'

    LOCAL_CHAT_VERIFIED="false"
    OPENCLAW_PREVIEWED="false"
    OPENCLAW_IMPORTED="false"
    save_launcher_state

    set_last_action "已启动卸载，日志：$log_path"
    run_in_terminal "$payload" "Hermes 卸载" "$log_path"
}

show_official_resources() {
    local picked=""
    picked="$(choose_from_list "选择要打开的官方资源。" "官方文档" "官方文档" "官方仓库" "返回")" || return 0
    case "$picked" in
        "官方文档") open "$OFFICIAL_DOCS_URL" ;;
        "官方仓库") open "$OFFICIAL_REPO_URL" ;;
        *) ;;
    esac
}

show_stage_menu() {
    local stage_id="$1"
    local picked=""

    case "$stage_id" in
        "1")
            picked="$(choose_from_list "步骤 1：安装 Hermes\n\n官方 macOS 路线是 install.sh。这里默认建议安装后跳过官方 setup，回到启动器继续下一步。" "安装 / 更新 Hermes" "安装 / 更新 Hermes" "返回")" || return 0
            [[ "$picked" == "安装 / 更新 Hermes" ]] && launch_install
            ;;
        "2")
            picked="$(choose_from_list "步骤 2：迁移 OpenClaw\n\n$( [[ -n "$OPENCLAW_LIST" ]] && printf '已检测到来源目录：%s' "$OPENCLAW_LIST" || printf '当前未检测到 OpenClaw 默认目录，可直接跳过。' )" "预览导入 OpenClaw" "预览导入 OpenClaw" "正式导入 OpenClaw" "返回")" || return 0
            case "$picked" in
                "预览导入 OpenClaw") preview_openclaw ;;
                "正式导入 OpenClaw") import_openclaw ;;
                *) ;;
            esac
            ;;
        "3")
            picked="$(choose_from_list "步骤 3：配置模型与 API Key\n\n官方文档建议安装后先完成 provider 与 API Key，再开始对话。" "配置模型与 API Key" "配置模型与 API Key" "返回")" || return 0
            [[ "$picked" == "配置模型与 API Key" ]] && configure_model
            ;;
        "4")
            picked="$(choose_from_list "步骤 4：快速检测与诊断\n\n中文快速检测适合普通用户；doctor 适合排错。" "快速检测" "快速检测" "运行 doctor" "返回")" || return 0
            case "$picked" in
                "快速检测") show_message "$(quick_check_summary)" ;;
                "运行 doctor") run_doctor ;;
                *) ;;
            esac
            ;;
        "5")
            picked="$(choose_from_list "步骤 5：启动本地对话\n\n先在本机终端实际问一轮，确认 Hermes 回复正常，再继续消息渠道配置。" "启动本地对话" "启动本地对话" "已验证本地对话，继续配置消息渠道" "返回")" || return 0
            case "$picked" in
                "启动本地对话") launch_local_chat ;;
                "已验证本地对话，继续配置消息渠道")
                    mark_local_chat_verified
                    configure_gateway
                    ;;
                *) ;;
            esac
            ;;
        "6")
            local gateway_prompt="步骤 6：配置并启动消息网关\n\n"
            if [[ "$GATEWAY_RUNTIME" == "true" ]]; then
                gateway_prompt+="已检测到消息网关正在运行。保持终端窗口打开即可。"
            elif [[ "$GATEWAY_CONFIGURED" == "true" ]]; then
                gateway_prompt+="已检测到消息渠道配置：$CONNECTED_PLATFORMS。"
                [[ "$GATEWAY_NEEDS_DEPS" == "true" ]] && gateway_prompt+="\n当前还缺少部分消息渠道依赖，启动时会先自动安装。"
            else
                gateway_prompt+="当前还没有检测到有效的消息渠道配置。"
            fi
            picked="$(choose_from_list "$gateway_prompt" "配置消息渠道" "配置消息渠道" "启动消息网关" "返回")" || return 0
            case "$picked" in
                "配置消息渠道") configure_gateway ;;
                "启动消息网关")
                    if [[ "$GATEWAY_CONFIGURED" != "true" ]]; then
                        show_warning "当前还没有检测到已配置的消息渠道，请先完成消息渠道配置。"
                    else
                        install_messaging_and_gateway
                    fi
                    ;;
                *) ;;
            esac
            ;;
        "7")
            picked="$(choose_from_list "步骤 7：高级配置与维护\n\n这里放的是增强能力和维护动作，不是基础对话的必需项。" "打开 config.yaml" "打开 config.yaml" "打开 .env" "打开日志目录" "运行 update" "配置 tools" "完整 setup" "卸载 / 重装" "返回")" || return 0
            case "$picked" in
                "打开 config.yaml") open_path "$HERMES_HOME/config.yaml" ;;
                "打开 .env") open_path "$HERMES_HOME/.env" ;;
                "打开日志目录") open_path "$HERMES_HOME/logs" ;;
                "运行 update") run_update ;;
                "配置 tools") run_tools ;;
                "完整 setup") run_full_setup ;;
                "卸载 / 重装") uninstall_hermes ;;
                *) ;;
            esac
            ;;
    esac
}

execute_recommended_action() {
    case "$RECOMMENDATION_ACTION_ID" in
        "install") launch_install ;;
        "openclaw-preview") preview_openclaw ;;
        "openclaw-import") import_openclaw ;;
        "model") configure_model ;;
        "launch") launch_local_chat ;;
        "gateway-setup") configure_gateway ;;
        "use-mode")
            local picked=""
            if [[ "$GATEWAY_CONFIGURED" == "true" ]]; then
                picked="$(choose_from_list "当前已经进入可用状态。你要继续哪种方式？" "开始本地对话" "开始本地对话" "启动消息网关" "返回")" || return 0
                case "$picked" in
                    "开始本地对话") launch_local_chat ;;
                    "启动消息网关") install_messaging_and_gateway ;;
                    *) ;;
                esac
            else
                picked="$(choose_from_list "本地对话已经可用。你要继续本地使用，还是去配置消息渠道？" "开始本地对话" "开始本地对话" "配置消息渠道" "返回")" || return 0
                case "$picked" in
                    "开始本地对话") launch_local_chat ;;
                    "配置消息渠道") configure_gateway ;;
                    *) ;;
                esac
            fi
            ;;
    esac
}

show_main_menu() {
    collect_state
    local picked=""
    picked="$(choose_from_list "$(status_text)" "执行推荐操作：$RECOMMENDATION_LABEL" \
        "执行推荐操作：$RECOMMENDATION_LABEL" \
        "步骤 1：安装 Hermes" \
        "步骤 2：迁移 OpenClaw" \
        "步骤 3：配置模型与 API Key" \
        "步骤 4：快速检测与诊断" \
        "步骤 5：启动本地对话" \
        "步骤 6：配置并启动消息网关" \
        "步骤 7：高级配置与维护" \
        "打开数据目录" \
        "打开安装目录" \
        "官方资源" \
        "退出")" || return 1

    case "$picked" in
        "执行推荐操作：$RECOMMENDATION_LABEL") execute_recommended_action ;;
        "步骤 1：安装 Hermes") show_stage_menu "1" ;;
        "步骤 2：迁移 OpenClaw") show_stage_menu "2" ;;
        "步骤 3：配置模型与 API Key") show_stage_menu "3" ;;
        "步骤 4：快速检测与诊断") show_stage_menu "4" ;;
        "步骤 5：启动本地对话") show_stage_menu "5" ;;
        "步骤 6：配置并启动消息网关") show_stage_menu "6" ;;
        "步骤 7：高级配置与维护") show_stage_menu "7" ;;
        "打开数据目录") open_path "$HERMES_HOME" ;;
        "打开安装目录") open_path "$INSTALL_DIR" ;;
        "官方资源") show_official_resources ;;
        *) return 1 ;;
    esac

    return 0
}

main() {
    if [[ "${1:-}" == "--self-test" ]]; then
        printf 'HermesHome=%s\nInstallDir=%s\nBranch=%s\n' "$HERMES_HOME" "$INSTALL_DIR" "$BRANCH"
        exit 0
    fi

    if [[ "$(uname -s)" != "Darwin" ]]; then
        show_warning "这个启动器只用于 macOS。当前系统不是 macOS。"
        exit 1
    fi

    ensure_launcher_dirs
    set_last_action "启动器已就绪"

    while true; do
        if ! show_main_menu; then
            exit 0
        fi
    done
}

main "$@"
